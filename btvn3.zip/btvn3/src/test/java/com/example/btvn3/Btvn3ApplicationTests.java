package com.example.btvn3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Btvn3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
